N = 7;
for mm = 1:N
    for nn = 1:mm
        fprintf('*');
    end
    fprintf('\n');
end
